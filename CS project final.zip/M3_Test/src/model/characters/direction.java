package model.characters;

public enum direction {
	UP, DOWN, LEFT, RIGHT
}
